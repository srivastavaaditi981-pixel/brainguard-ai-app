import { useEffect, useState } from 'react';
import { useAuth } from 'miaoda-auth-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Activity, Mic, Keyboard, TrendingUp, Plus } from 'lucide-react';
import { getMonitoringData, getMonitoringDataByType, addMonitoringData } from '@/db/api';
import type { MonitoringData, DataType } from '@/types/types';
import { useToast } from '@/hooks/use-toast';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function Monitoring() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [allData, setAllData] = useState<MonitoringData[]>([]);
  const [activeTab, setActiveTab] = useState<DataType>('speech');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newDataType, setNewDataType] = useState<DataType>('speech');
  const [newScore, setNewScore] = useState('');

  useEffect(() => {
    if (user) {
      loadMonitoringData();
    }
  }, [user]);

  const loadMonitoringData = async () => {
    try {
      setLoading(true);
      const data = await getMonitoringData(user!.id, 100);
      setAllData(data);
    } catch (error: any) {
      toast({
        title: 'Error Loading Data',
        description: error.message || 'Failed to load monitoring data',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleAddData = async () => {
    try {
      const score = Number.parseFloat(newScore);
      if (Number.isNaN(score) || score < 0 || score > 100) {
        toast({
          title: 'Invalid Score',
          description: 'Score must be a number between 0 and 100',
          variant: 'destructive'
        });
        return;
      }

      const metrics = {
        timestamp: new Date().toISOString(),
        type: newDataType
      };

      await addMonitoringData(user!.id, newDataType, metrics, score);
      
      toast({
        title: 'Data Added',
        description: 'Monitoring data has been recorded successfully'
      });

      setDialogOpen(false);
      setNewScore('');
      loadMonitoringData();
    } catch (error: any) {
      toast({
        title: 'Error Adding Data',
        description: error.message || 'Failed to add monitoring data',
        variant: 'destructive'
      });
    }
  };

  const getChartData = (dataType: DataType) => {
    return allData
      .filter(d => d.data_type === dataType)
      .slice(0, 20)
      .reverse()
      .map(d => ({
        date: new Date(d.recorded_at).toLocaleDateString(),
        score: d.score || 0
      }));
  };

  const getLatestScore = (dataType: DataType) => {
    const data = allData.find(d => d.data_type === dataType);
    return data?.score || 0;
  };

  const getDataIcon = (dataType: DataType) => {
    switch (dataType) {
      case 'speech': return <Mic className="w-5 h-5" />;
      case 'typing': return <Keyboard className="w-5 h-5" />;
      case 'activity': return <Activity className="w-5 h-5" />;
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto p-4 space-y-6">
        <Skeleton className="h-12 w-64 bg-muted" />
        <Skeleton className="h-96 w-full bg-muted" />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 space-y-6 max-w-6xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Monitoring</h1>
          <p className="text-muted-foreground mt-1">Track your cognitive health metrics</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Add Data
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Monitoring Data</DialogTitle>
              <DialogDescription>
                Record new monitoring data for tracking
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="data-type">Data Type</Label>
                <Select value={newDataType} onValueChange={(value) => setNewDataType(value as DataType)}>
                  <SelectTrigger id="data-type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="speech">Speech Pattern</SelectItem>
                    <SelectItem value="typing">Typing Speed</SelectItem>
                    <SelectItem value="activity">Activity Level</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="score">Score (0-100)</Label>
                <Input
                  id="score"
                  type="number"
                  min="0"
                  max="100"
                  value={newScore}
                  onChange={(e) => setNewScore(e.target.value)}
                  placeholder="Enter score"
                />
              </div>
              <Button onClick={handleAddData} className="w-full">
                Add Data
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="card-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Speech Pattern</CardTitle>
            <Mic className="w-5 h-5 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{getLatestScore('speech')}</div>
            <p className="text-xs text-muted-foreground mt-1">Latest score</p>
          </CardContent>
        </Card>

        <Card className="card-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Typing Speed</CardTitle>
            <Keyboard className="w-5 h-5 text-secondary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{getLatestScore('typing')}</div>
            <p className="text-xs text-muted-foreground mt-1">Latest score</p>
          </CardContent>
        </Card>

        <Card className="card-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Activity Level</CardTitle>
            <Activity className="w-5 h-5 text-accent" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{getLatestScore('activity')}</div>
            <p className="text-xs text-muted-foreground mt-1">Latest score</p>
          </CardContent>
        </Card>
      </div>

      <Card className="card-shadow">
        <CardHeader>
          <CardTitle>Monitoring Trends</CardTitle>
          <CardDescription>View your cognitive health metrics over time</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as DataType)}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="speech">Speech</TabsTrigger>
              <TabsTrigger value="typing">Typing</TabsTrigger>
              <TabsTrigger value="activity">Activity</TabsTrigger>
            </TabsList>
            
            {(['speech', 'typing', 'activity'] as DataType[]).map((type) => (
              <TabsContent key={type} value={type} className="mt-6">
                {getChartData(type).length > 0 ? (
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={getChartData(type)}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis domain={[0, 100]} />
                      <Tooltip />
                      <Legend />
                      <Line
                        type="monotone"
                        dataKey="score"
                        stroke="hsl(var(--primary))"
                        strokeWidth={2}
                        dot={{ fill: 'hsl(var(--primary))' }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    {getDataIcon(type)}
                    <p className="text-muted-foreground mt-4">No data available for {type}</p>
                    <Button variant="outline" className="mt-4" onClick={() => setDialogOpen(true)}>
                      Add First Entry
                    </Button>
                  </div>
                )}
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>

      {allData.length > 0 && (
        <Card className="card-shadow">
          <CardHeader>
            <CardTitle>Recent Entries</CardTitle>
            <CardDescription>Your latest monitoring data</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {allData.slice(0, 10).map((data) => (
                <div key={data.id} className="flex items-center justify-between p-3 rounded-lg border bg-card">
                  <div className="flex items-center gap-3">
                    {getDataIcon(data.data_type)}
                    <div>
                      <p className="font-medium capitalize">{data.data_type}</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(data.recorded_at).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <Badge variant="secondary" className="text-lg font-bold">
                    {data.score}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
