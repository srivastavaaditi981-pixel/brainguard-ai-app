import { useEffect, useState } from 'react';
import { useAuth } from 'miaoda-auth-react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  Brain,
  TrendingUp,
  TrendingDown,
  Bell,
  Lightbulb,
  Activity,
  AlertCircle,
  CheckCircle2,
  Phone,
  Video,
  Mail,
  Calendar
} from 'lucide-react';
import { getDashboardStats, getUnreadAlerts, getActiveRecommendations, getLatestMonitoringData, getCaregiverAssignments, getProfile } from '@/db/api';
import type { Alert, Recommendation, MonitoringData, CaregiverAssignment, Profile } from '@/types/types';
import { useToast } from '@/hooks/use-toast';

export default function Home() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [cognitiveScore, setCognitiveScore] = useState(0);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [latestData, setLatestData] = useState<MonitoringData | null>(null);
  const [caregivers, setCaregivers] = useState<Array<{ assignment: CaregiverAssignment; profile: Profile }>>([]);

  useEffect(() => {
    if (user) {
      loadDashboardData();
    }
  }, [user]);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      const [stats, alertsData, recsData, latest, assignments] = await Promise.all([
        getDashboardStats(user!.id),
        getUnreadAlerts(user!.id),
        getActiveRecommendations(user!.id),
        getLatestMonitoringData(user!.id),
        getCaregiverAssignments(user!.id)
      ]);

      setCognitiveScore(stats.cognitiveScore);
      setAlerts(alertsData.slice(0, 3));
      setRecommendations(recsData.slice(0, 3));
      setLatestData(latest);

      const caregiversData = [];
      for (const assignment of assignments.slice(0, 2)) {
        const profile = await getProfile(assignment.caregiver_id);
        if (profile && (profile.role === 'healthcare_professional' || profile.role === 'caregiver')) {
          caregiversData.push({ assignment, profile });
        }
      }
      setCaregivers(caregiversData);
    } catch (error: any) {
      toast({
        title: 'Error Loading Dashboard',
        description: error.message || 'Failed to load dashboard data',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-secondary';
    if (score >= 60) return 'text-accent';
    return 'text-destructive';
  };

  const getScoreStatus = (score: number) => {
    if (score >= 80) return 'Excellent';
    if (score >= 60) return 'Good';
    if (score >= 40) return 'Fair';
    return 'Needs Attention';
  };

  const getScoreIcon = (score: number) => {
    if (score >= 60) return <TrendingUp className="w-6 h-6" />;
    return <TrendingDown className="w-6 h-6" />;
  };

  const getInitials = (name?: string | null) => {
    if (!name) return 'U';
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  if (loading) {
    return (
      <div className="container mx-auto p-4 space-y-6">
        <Skeleton className="h-48 w-full bg-muted" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Skeleton className="h-64 bg-muted" />
          <Skeleton className="h-64 bg-muted" />
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 space-y-6 max-w-6xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground mt-1">Your cognitive health overview</p>
        </div>
      </div>

      <Card className="bg-gradient-to-br from-primary/10 to-secondary/10 border-none card-shadow">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Brain className="w-8 h-8 text-primary" />
                <h2 className="text-2xl font-bold text-foreground">Cognitive Health Score</h2>
              </div>
              <div className="flex items-center gap-3">
                <span className={`text-5xl font-bold ${getScoreColor(cognitiveScore)}`}>
                  {cognitiveScore}
                </span>
                <div className="flex flex-col">
                  <span className="text-sm text-muted-foreground">out of 100</span>
                  <Badge variant="secondary" className="w-fit">
                    {getScoreStatus(cognitiveScore)}
                  </Badge>
                </div>
              </div>
              <Progress value={cognitiveScore} className="h-3 w-64" />
            </div>
            <div className={getScoreColor(cognitiveScore)}>
              {getScoreIcon(cognitiveScore)}
            </div>
          </div>
          {latestData && (
            <p className="text-sm text-muted-foreground mt-4">
              Last monitored: {new Date(latestData.recorded_at).toLocaleString()}
            </p>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        <Card className="card-shadow hover:shadow-lg transition-shadow cursor-pointer" onClick={() => navigate('/monitoring')}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Monitoring</CardTitle>
            <Activity className="w-5 h-5 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{latestData ? 'Active' : 'No Data'}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {latestData ? 'Tracking your daily activities' : 'Start monitoring'}
            </p>
          </CardContent>
        </Card>

        <Card className="card-shadow hover:shadow-lg transition-shadow cursor-pointer" onClick={() => navigate('/daily-routine')}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Daily Routine</CardTitle>
            <Calendar className="w-5 h-5 text-secondary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Track</div>
            <p className="text-xs text-muted-foreground mt-1">
              Record your daily activities
            </p>
          </CardContent>
        </Card>

        <Card className="card-shadow hover:shadow-lg transition-shadow cursor-pointer" onClick={() => navigate('/alerts')}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Alerts</CardTitle>
            <Bell className="w-5 h-5 text-accent" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{alerts.length}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {alerts.length > 0 ? 'Unread notifications' : 'No new alerts'}
            </p>
          </CardContent>
        </Card>

        <Card className="card-shadow hover:shadow-lg transition-shadow cursor-pointer" onClick={() => navigate('/recommendations')}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Recommendations</CardTitle>
            <Lightbulb className="w-5 h-5 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{recommendations.length}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {recommendations.length > 0 ? 'Active suggestions' : 'All caught up'}
            </p>
          </CardContent>
        </Card>
      </div>

      {alerts.length > 0 && (
        <Card className="card-shadow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-accent" />
              Recent Alerts
            </CardTitle>
            <CardDescription>Important notifications about your cognitive health</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {alerts.map((alert) => (
              <div
                key={alert.id}
                className="flex items-start gap-3 p-3 rounded-lg border bg-card hover:bg-muted/50 transition-colors cursor-pointer"
                onClick={() => navigate('/alerts')}
              >
                <div className={`mt-1 ${
                  alert.alert_type === 'critical' ? 'text-destructive' :
                  alert.alert_type === 'warning' ? 'text-accent' :
                  'text-primary'
                }`}>
                  <AlertCircle className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm">{alert.title}</p>
                  {alert.description && (
                    <p className="text-sm text-muted-foreground line-clamp-2">{alert.description}</p>
                  )}
                  <p className="text-xs text-muted-foreground mt-1">
                    {new Date(alert.created_at).toLocaleDateString()}
                  </p>
                </div>
                <Badge variant={alert.alert_type === 'critical' ? 'destructive' : 'secondary'} className="capitalize">
                  {alert.alert_type}
                </Badge>
              </div>
            ))}
            <Button variant="outline" className="w-full" onClick={() => navigate('/alerts')}>
              View All Alerts
            </Button>
          </CardContent>
        </Card>
      )}

      {recommendations.length > 0 && (
        <Card className="card-shadow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lightbulb className="w-5 h-5 text-secondary" />
              Personalized Recommendations
            </CardTitle>
            <CardDescription>Suggestions to improve your cognitive health</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {recommendations.map((rec) => (
              <div
                key={rec.id}
                className="flex items-start gap-3 p-3 rounded-lg border bg-card hover:bg-muted/50 transition-colors"
              >
                <CheckCircle2 className="w-5 h-5 text-secondary mt-1" />
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm">{rec.title}</p>
                  {rec.description && (
                    <p className="text-sm text-muted-foreground line-clamp-2">{rec.description}</p>
                  )}
                </div>
                <Badge variant="outline" className="capitalize">
                  {rec.category.replace('_', ' ')}
                </Badge>
              </div>
            ))}
            <Button variant="outline" className="w-full" onClick={() => navigate('/recommendations')}>
              View All Recommendations
            </Button>
          </CardContent>
        </Card>
      )}

      {alerts.length === 0 && recommendations.length === 0 && !latestData && (
        <Card className="card-shadow">
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <Brain className="w-16 h-16 text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold mb-2">Welcome to Brain Guard!</h3>
            <p className="text-muted-foreground max-w-md mb-6">
              Start monitoring your cognitive health to receive personalized insights and recommendations.
            </p>
            <Button onClick={() => navigate('/monitoring')}>
              Start Monitoring
            </Button>
          </CardContent>
        </Card>
      )}

      {caregivers.length > 0 && (
        <Card className="card-shadow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Phone className="w-5 h-5" />
              Your Healthcare Team
            </CardTitle>
            <CardDescription>Contact your caregivers and healthcare professionals</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {caregivers.map(({ assignment, profile }) => (
              <div
                key={assignment.id}
                className="flex items-center gap-4 p-4 rounded-lg border bg-card hover:bg-muted/50 transition-colors"
              >
                <Avatar className="w-12 h-12">
                  <AvatarFallback className="bg-primary text-primary-foreground">
                    {getInitials(profile.full_name || profile.username)}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold">{profile.full_name || profile.username}</p>
                  <Badge variant="secondary" className="capitalize text-xs mt-1">
                    {profile.role.replace('_', ' ')}
                  </Badge>
                  {profile.phone && (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                      <Phone className="w-3 h-3" />
                      <span>{profile.phone}</span>
                    </div>
                  )}
                  {profile.email && (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                      <Mail className="w-3 h-3" />
                      <span>{profile.email}</span>
                    </div>
                  )}
                </div>
                <Button
                  size="sm"
                  onClick={() => navigate('/video-call')}
                  className="flex-shrink-0"
                >
                  <Video className="w-4 h-4 mr-2" />
                  Call
                </Button>
              </div>
            ))}
            <Button variant="outline" className="w-full" onClick={() => navigate('/video-call')}>
              View All Contacts
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
