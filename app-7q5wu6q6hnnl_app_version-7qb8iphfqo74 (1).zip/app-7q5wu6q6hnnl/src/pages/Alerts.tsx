import { useEffect, useState } from 'react';
import { useAuth } from 'miaoda-auth-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertCircle, Bell, CheckCircle, Info } from 'lucide-react';
import { getAlerts, markAlertAsRead } from '@/db/api';
import type { Alert, AlertType } from '@/types/types';
import { useToast } from '@/hooks/use-toast';

export default function Alerts() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [filter, setFilter] = useState<'all' | AlertType>('all');

  useEffect(() => {
    if (user) {
      loadAlerts();
    }
  }, [user]);

  const loadAlerts = async () => {
    try {
      setLoading(true);
      const data = await getAlerts(user!.id);
      setAlerts(data);
    } catch (error: any) {
      toast({
        title: 'Error Loading Alerts',
        description: error.message || 'Failed to load alerts',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleMarkAsRead = async (alertId: string) => {
    try {
      await markAlertAsRead(alertId);
      setAlerts(alerts.map(a => a.id === alertId ? { ...a, is_read: true } : a));
      toast({
        title: 'Alert Marked as Read',
        description: 'The alert has been marked as read'
      });
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to mark alert as read',
        variant: 'destructive'
      });
    }
  };

  const getAlertIcon = (type: AlertType) => {
    switch (type) {
      case 'critical': return <AlertCircle className="w-5 h-5 text-destructive" />;
      case 'warning': return <AlertCircle className="w-5 h-5 text-accent" />;
      case 'info': return <Info className="w-5 h-5 text-primary" />;
    }
  };

  const getAlertBadgeVariant = (type: AlertType) => {
    switch (type) {
      case 'critical': return 'destructive';
      case 'warning': return 'default';
      case 'info': return 'secondary';
    }
  };

  const filteredAlerts = filter === 'all' 
    ? alerts 
    : alerts.filter(a => a.alert_type === filter);

  const unreadCount = alerts.filter(a => !a.is_read).length;

  if (loading) {
    return (
      <div className="container mx-auto p-4 space-y-6">
        <Skeleton className="h-12 w-64 bg-muted" />
        <Skeleton className="h-96 w-full bg-muted" />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 space-y-6 max-w-4xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center gap-2">
            <Bell className="w-8 h-8" />
            Alerts
          </h1>
          <p className="text-muted-foreground mt-1">
            {unreadCount > 0 ? `${unreadCount} unread notification${unreadCount > 1 ? 's' : ''}` : 'All caught up!'}
          </p>
        </div>
      </div>

      <Tabs value={filter} onValueChange={(v) => setFilter(v as 'all' | AlertType)}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">All ({alerts.length})</TabsTrigger>
          <TabsTrigger value="critical">Critical</TabsTrigger>
          <TabsTrigger value="warning">Warning</TabsTrigger>
          <TabsTrigger value="info">Info</TabsTrigger>
        </TabsList>

        <TabsContent value={filter} className="mt-6 space-y-4">
          {filteredAlerts.length > 0 ? (
            filteredAlerts.map((alert) => (
              <Card 
                key={alert.id} 
                className={`card-shadow transition-all ${!alert.is_read ? 'border-l-4 border-l-primary' : ''}`}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3 flex-1">
                      {getAlertIcon(alert.alert_type)}
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <CardTitle className="text-lg">{alert.title}</CardTitle>
                          {!alert.is_read && (
                            <Badge variant="default" className="text-xs">New</Badge>
                          )}
                        </div>
                        {alert.description && (
                          <CardDescription className="text-base mt-2">
                            {alert.description}
                          </CardDescription>
                        )}
                        <div className="flex items-center gap-3 mt-3">
                          <Badge variant={getAlertBadgeVariant(alert.alert_type)} className="capitalize">
                            {alert.alert_type}
                          </Badge>
                          {alert.severity && (
                            <Badge variant="outline">
                              Severity: {alert.severity}/5
                            </Badge>
                          )}
                          <span className="text-xs text-muted-foreground">
                            {new Date(alert.created_at).toLocaleString()}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                {!alert.is_read && (
                  <CardContent>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleMarkAsRead(alert.id)}
                    >
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Mark as Read
                    </Button>
                  </CardContent>
                )}
              </Card>
            ))
          ) : (
            <Card className="card-shadow">
              <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                <Bell className="w-16 h-16 text-muted-foreground mb-4" />
                <h3 className="text-xl font-semibold mb-2">No Alerts</h3>
                <p className="text-muted-foreground">
                  {filter === 'all' 
                    ? "You don't have any alerts yet" 
                    : `No ${filter} alerts found`}
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
