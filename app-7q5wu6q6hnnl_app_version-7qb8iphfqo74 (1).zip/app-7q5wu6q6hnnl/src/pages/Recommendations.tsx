import { useEffect, useState } from 'react';
import { useAuth } from 'miaoda-auth-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Lightbulb, Brain, Heart, Apple, Dumbbell, Stethoscope } from 'lucide-react';
import { getRecommendations, toggleRecommendationComplete } from '@/db/api';
import type { Recommendation, RecommendationCategory } from '@/types/types';
import { useToast } from '@/hooks/use-toast';

export default function Recommendations() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [filter, setFilter] = useState<'all' | 'active' | 'completed'>('active');

  useEffect(() => {
    if (user) {
      loadRecommendations();
    }
  }, [user]);

  const loadRecommendations = async () => {
    try {
      setLoading(true);
      const data = await getRecommendations(user!.id);
      setRecommendations(data);
    } catch (error: any) {
      toast({
        title: 'Error Loading Recommendations',
        description: error.message || 'Failed to load recommendations',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleToggleComplete = async (id: string, currentStatus: boolean) => {
    try {
      await toggleRecommendationComplete(id, !currentStatus);
      setRecommendations(recommendations.map(r => 
        r.id === id ? { ...r, is_completed: !currentStatus } : r
      ));
      toast({
        title: currentStatus ? 'Marked as Incomplete' : 'Marked as Complete',
        description: 'Recommendation status updated'
      });
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to update recommendation',
        variant: 'destructive'
      });
    }
  };

  const getCategoryIcon = (category: RecommendationCategory) => {
    switch (category) {
      case 'cognitive_exercise': return <Brain className="w-5 h-5 text-primary" />;
      case 'lifestyle': return <Heart className="w-5 h-5 text-secondary" />;
      case 'dietary': return <Apple className="w-5 h-5 text-accent" />;
      case 'physical': return <Dumbbell className="w-5 h-5 text-primary" />;
      case 'medical': return <Stethoscope className="w-5 h-5 text-destructive" />;
    }
  };

  const filteredRecommendations = recommendations.filter(r => {
    if (filter === 'active') return !r.is_completed;
    if (filter === 'completed') return r.is_completed;
    return true;
  });

  const activeCount = recommendations.filter(r => !r.is_completed).length;
  const completedCount = recommendations.filter(r => r.is_completed).length;

  if (loading) {
    return (
      <div className="container mx-auto p-4 space-y-6">
        <Skeleton className="h-12 w-64 bg-muted" />
        <Skeleton className="h-96 w-full bg-muted" />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 space-y-6 max-w-4xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center gap-2">
            <Lightbulb className="w-8 h-8" />
            Recommendations
          </h1>
          <p className="text-muted-foreground mt-1">
            Personalized suggestions to improve your cognitive health
          </p>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card className="card-shadow">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Total</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{recommendations.length}</div>
          </CardContent>
        </Card>
        <Card className="card-shadow">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Active</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{activeCount}</div>
          </CardContent>
        </Card>
        <Card className="card-shadow">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Completed</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-secondary">{completedCount}</div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={filter} onValueChange={(v) => setFilter(v as 'all' | 'active' | 'completed')}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="active">Active ({activeCount})</TabsTrigger>
          <TabsTrigger value="completed">Completed ({completedCount})</TabsTrigger>
          <TabsTrigger value="all">All ({recommendations.length})</TabsTrigger>
        </TabsList>

        <TabsContent value={filter} className="mt-6 space-y-4">
          {filteredRecommendations.length > 0 ? (
            filteredRecommendations.map((rec) => (
              <Card 
                key={rec.id} 
                className={`card-shadow transition-all ${rec.is_completed ? 'opacity-75' : ''}`}
              >
                <CardHeader>
                  <div className="flex items-start gap-4">
                    <Checkbox
                      checked={rec.is_completed}
                      onCheckedChange={() => handleToggleComplete(rec.id, rec.is_completed)}
                      className="mt-1"
                    />
                    <div className="flex-1">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex items-center gap-2 flex-1">
                          {getCategoryIcon(rec.category)}
                          <CardTitle className={`text-lg ${rec.is_completed ? 'line-through' : ''}`}>
                            {rec.title}
                          </CardTitle>
                        </div>
                        <Badge variant="outline" className="capitalize">
                          {rec.category.replace('_', ' ')}
                        </Badge>
                      </div>
                      {rec.description && (
                        <CardDescription className="text-base mt-2 ml-7">
                          {rec.description}
                        </CardDescription>
                      )}
                      <div className="flex items-center gap-3 mt-3 ml-7">
                        <span className="text-xs text-muted-foreground">
                          Added {new Date(rec.created_at).toLocaleDateString()}
                        </span>
                        {rec.is_completed && (
                          <Badge variant="secondary" className="text-xs">
                            ✓ Completed
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </CardHeader>
              </Card>
            ))
          ) : (
            <Card className="card-shadow">
              <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                <Lightbulb className="w-16 h-16 text-muted-foreground mb-4" />
                <h3 className="text-xl font-semibold mb-2">No Recommendations</h3>
                <p className="text-muted-foreground">
                  {filter === 'active' && 'All recommendations are completed!'}
                  {filter === 'completed' && 'No completed recommendations yet'}
                  {filter === 'all' && "You don't have any recommendations yet"}
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {activeCount > 0 && (
        <Card className="card-shadow bg-primary/5 border-primary/20">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <Lightbulb className="w-6 h-6 text-primary mt-1" />
              <div>
                <h3 className="font-semibold text-lg mb-2">Keep Going!</h3>
                <p className="text-muted-foreground">
                  You have {activeCount} active recommendation{activeCount > 1 ? 's' : ''} to work on. 
                  Following these suggestions can help improve your cognitive health.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
