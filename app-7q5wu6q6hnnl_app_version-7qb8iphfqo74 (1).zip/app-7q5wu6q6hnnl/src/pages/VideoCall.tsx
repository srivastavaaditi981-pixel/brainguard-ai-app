import { useEffect, useState } from 'react';
import { useAuth } from 'miaoda-auth-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Video, Phone, Mail, Calendar } from 'lucide-react';
import { getCaregiverAssignments, getProfile } from '@/db/api';
import type { CaregiverAssignment, Profile } from '@/types/types';
import { useToast } from '@/hooks/use-toast';

export default function VideoCall() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [caregivers, setCaregivers] = useState<Array<{ assignment: CaregiverAssignment; profile: Profile }>>([]);

  useEffect(() => {
    if (user) {
      loadCaregivers();
    }
  }, [user]);

  const loadCaregivers = async () => {
    try {
      setLoading(true);
      const assignments = await getCaregiverAssignments(user!.id);
      const caregiversData = [];
      
      for (const assignment of assignments) {
        const profile = await getProfile(assignment.caregiver_id);
        if (profile && (profile.role === 'healthcare_professional' || profile.role === 'caregiver')) {
          caregiversData.push({ assignment, profile });
        }
      }
      
      setCaregivers(caregiversData);
    } catch (error: any) {
      toast({
        title: 'Error Loading Caregivers',
        description: error.message || 'Failed to load caregivers',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleStartCall = (caregiverName: string) => {
    toast({
      title: 'Starting Video Call',
      description: `Connecting to ${caregiverName}...`
    });
  };

  const getInitials = (name?: string | null) => {
    if (!name) return 'U';
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  if (loading) {
    return (
      <div className="container mx-auto p-4 space-y-6">
        <Skeleton className="h-12 w-64 bg-muted" />
        <Skeleton className="h-96 w-full bg-muted" />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 space-y-6 max-w-4xl">
      <div>
        <h1 className="text-3xl font-bold text-foreground flex items-center gap-2">
          <Video className="w-8 h-8" />
          Video Consultation
        </h1>
        <p className="text-muted-foreground mt-1">Connect with your healthcare providers</p>
      </div>

      {caregivers.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {caregivers.map(({ assignment, profile }) => (
            <Card key={assignment.id} className="card-shadow">
              <CardHeader>
                <div className="flex items-center gap-4">
                  <Avatar className="w-16 h-16">
                    <AvatarFallback className="bg-primary text-primary-foreground text-xl">
                      {getInitials(profile.full_name || profile.username)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <CardTitle className="text-xl">{profile.full_name || profile.username}</CardTitle>
                    <CardDescription className="mt-1">
                      <Badge variant="secondary" className="capitalize">
                        {profile.role.replace('_', ' ')}
                      </Badge>
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {profile.phone && (
                  <div className="flex items-center gap-3 text-sm">
                    <Phone className="w-4 h-4 text-muted-foreground" />
                    <span>{profile.phone}</span>
                  </div>
                )}
                {profile.email && (
                  <div className="flex items-center gap-3 text-sm">
                    <Mail className="w-4 h-4 text-muted-foreground" />
                    <span>{profile.email}</span>
                  </div>
                )}
                {assignment.relationship && (
                  <div className="flex items-center gap-3 text-sm">
                    <Calendar className="w-4 h-4 text-muted-foreground" />
                    <span>{assignment.relationship}</span>
                  </div>
                )}
                <div className="pt-2">
                  <Button 
                    className="w-full" 
                    onClick={() => handleStartCall(profile.full_name || profile.username)}
                  >
                    <Video className="w-4 h-4 mr-2" />
                    Start Video Call
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="card-shadow">
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <Video className="w-16 h-16 text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold mb-2">No Healthcare Providers</h3>
            <p className="text-muted-foreground">
              You don't have any healthcare providers assigned yet. Add caregivers to enable video consultations.
            </p>
          </CardContent>
        </Card>
      )}

      <Card className="card-shadow bg-primary/5 border-primary/20">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <Video className="w-6 h-6 text-primary mt-1" />
            <div>
              <h3 className="font-semibold text-lg mb-2">Video Call Features</h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• High-quality video and audio</li>
                <li>• Secure and encrypted connections</li>
                <li>• Screen sharing capabilities</li>
                <li>• Call recording (with consent)</li>
                <li>• Available 24/7 for emergencies</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
