import { useEffect, useState } from 'react';
import { useAuth } from 'miaoda-auth-react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Heart, Activity, Bell, TrendingUp } from 'lucide-react';
import { getAssignedSeniors, getProfile, getDashboardStats, getUnreadAlerts } from '@/db/api';
import type { CaregiverAssignment, Profile } from '@/types/types';
import { useToast } from '@/hooks/use-toast';

interface PatientData {
  assignment: CaregiverAssignment;
  profile: Profile;
  cognitiveScore: number;
  alertCount: number;
}

export default function Patients() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [patients, setPatients] = useState<PatientData[]>([]);

  useEffect(() => {
    if (user) {
      loadPatients();
    }
  }, [user]);

  const loadPatients = async () => {
    try {
      setLoading(true);
      const assignments = await getAssignedSeniors(user!.id);
      
      const patientsData: PatientData[] = [];
      for (const assignment of assignments) {
        const profile = await getProfile(assignment.senior_id);
        if (profile) {
          const stats = await getDashboardStats(assignment.senior_id);
          const alerts = await getUnreadAlerts(assignment.senior_id);
          patientsData.push({
            assignment,
            profile,
            cognitiveScore: stats.cognitiveScore,
            alertCount: alerts.length
          });
        }
      }
      setPatients(patientsData);
    } catch (error: any) {
      toast({
        title: 'Error Loading Patients',
        description: error.message || 'Failed to load patients',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const getInitials = (name?: string | null) => {
    if (!name) return 'U';
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-secondary';
    if (score >= 60) return 'text-accent';
    return 'text-destructive';
  };

  if (loading) {
    return (
      <div className="container mx-auto p-4 space-y-6">
        <Skeleton className="h-12 w-64 bg-muted" />
        <Skeleton className="h-96 w-full bg-muted" />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 space-y-6 max-w-6xl">
      <div>
        <h1 className="text-3xl font-bold text-foreground flex items-center gap-2">
          <Heart className="w-8 h-8" />
          My Patients
        </h1>
        <p className="text-muted-foreground mt-1">Monitor the health of your assigned seniors</p>
      </div>

      {patients.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {patients.map(({ assignment, profile, cognitiveScore, alertCount }) => (
            <Card key={assignment.id} className="card-shadow hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-4">
                    <Avatar className="w-12 h-12">
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        {getInitials(profile.full_name || profile.username)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <CardTitle>{profile.full_name || profile.username}</CardTitle>
                      <CardDescription>@{profile.username}</CardDescription>
                      {assignment.relationship && (
                        <Badge variant="outline" className="mt-1">
                          {assignment.relationship}
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2">
                    <Activity className="w-5 h-5 text-primary" />
                    <span className="text-sm font-medium">Cognitive Score</span>
                  </div>
                  <span className={`text-2xl font-bold ${getScoreColor(cognitiveScore)}`}>
                    {cognitiveScore}
                  </span>
                </div>

                {assignment.can_view_alerts && alertCount > 0 && (
                  <div className="flex items-center gap-2 p-3 rounded-lg bg-accent/10 border border-accent/20">
                    <Bell className="w-5 h-5 text-accent" />
                    <span className="text-sm font-medium">
                      {alertCount} unread alert{alertCount > 1 ? 's' : ''}
                    </span>
                  </div>
                )}

                <div className="flex gap-2 text-xs text-muted-foreground">
                  {assignment.can_view_alerts && (
                    <Badge variant="secondary" className="text-xs">
                      Can View Alerts
                    </Badge>
                  )}
                  {assignment.can_view_data && (
                    <Badge variant="secondary" className="text-xs">
                      Can View Data
                    </Badge>
                  )}
                </div>

                <p className="text-xs text-muted-foreground">
                  Assigned since {new Date(assignment.created_at).toLocaleDateString()}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="card-shadow">
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <Heart className="w-16 h-16 text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold mb-2">No Patients Assigned</h3>
            <p className="text-muted-foreground">
              You don't have any patients assigned to you yet
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
