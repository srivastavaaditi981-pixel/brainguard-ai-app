import { useEffect, useState } from 'react';
import { useAuth } from 'miaoda-auth-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Calendar,
  Plus,
  Activity,
  TrendingUp,
  Clock,
  Smile,
  Brain,
  Trash2,
  BarChart3
} from 'lucide-react';
import {
  getDailyRoutines,
  createDailyRoutine,
  deleteDailyRoutine,
  getRoutineStats
} from '@/db/api';
import type { DailyRoutine, ActivityType } from '@/types/types';
import { useToast } from '@/hooks/use-toast';
import { useForm } from 'react-hook-form';
import { format } from 'date-fns';

const activityIcons: Record<ActivityType, any> = {
  exercise: Activity,
  meal: '🍽️',
  sleep: '😴',
  medication: '💊',
  social: '👥',
  cognitive: Brain,
  other: Calendar
};

const activityColors: Record<ActivityType, string> = {
  exercise: 'bg-green-500/10 text-green-700 border-green-200',
  meal: 'bg-orange-500/10 text-orange-700 border-orange-200',
  sleep: 'bg-blue-500/10 text-blue-700 border-blue-200',
  medication: 'bg-red-500/10 text-red-700 border-red-200',
  social: 'bg-purple-500/10 text-purple-700 border-purple-200',
  cognitive: 'bg-primary/10 text-primary border-primary/20',
  other: 'bg-muted text-muted-foreground border-border'
};

export default function DailyRoutinePage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [routines, setRoutines] = useState<DailyRoutine[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const form = useForm({
    defaultValues: {
      activity_type: 'exercise' as ActivityType,
      activity_name: '',
      duration_minutes: '',
      mood_rating: '',
      notes: ''
    }
  });

  useEffect(() => {
    if (user) {
      loadRoutines();
    }
  }, [user]);

  const loadRoutines = async () => {
    try {
      setLoading(true);
      const [routinesData, statsData] = await Promise.all([
        getDailyRoutines(user!.id, 20),
        getRoutineStats(user!.id, 7)
      ]);
      setRoutines(routinesData);
      setStats(statsData);
    } catch (error: any) {
      toast({
        title: 'Error Loading Routines',
        description: error.message || 'Failed to load daily routines',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const onSubmit = async (values: any) => {
    try {
      setSubmitting(true);
      await createDailyRoutine({
        user_id: user!.id,
        activity_type: values.activity_type,
        activity_name: values.activity_name,
        duration_minutes: values.duration_minutes ? parseInt(values.duration_minutes) : undefined,
        mood_rating: values.mood_rating ? parseInt(values.mood_rating) : undefined,
        notes: values.notes || undefined
      });

      toast({
        title: 'Activity Recorded',
        description: 'Your daily activity has been recorded successfully'
      });

      form.reset();
      setDialogOpen(false);
      loadRoutines();
    } catch (error: any) {
      toast({
        title: 'Error Recording Activity',
        description: error.message || 'Failed to record activity',
        variant: 'destructive'
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleDialogChange = (open: boolean) => {
    setDialogOpen(open);
    if (!open) {
      form.reset();
    }
  };

  const handleDelete = async (routineId: string) => {
    try {
      await deleteDailyRoutine(routineId);
      toast({
        title: 'Activity Deleted',
        description: 'The activity has been removed'
      });
      loadRoutines();
    } catch (error: any) {
      toast({
        title: 'Error Deleting Activity',
        description: error.message || 'Failed to delete activity',
        variant: 'destructive'
      });
    }
  };

  const getMoodEmoji = (rating: number | null) => {
    if (!rating) return '😐';
    if (rating >= 8) return '😄';
    if (rating >= 6) return '🙂';
    if (rating >= 4) return '😐';
    if (rating >= 2) return '😕';
    return '😢';
  };

  if (loading) {
    return (
      <div className="container mx-auto p-4 space-y-6 max-w-6xl">
        <Skeleton className="h-12 w-64 bg-muted" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Skeleton className="h-32 bg-muted" />
          <Skeleton className="h-32 bg-muted" />
          <Skeleton className="h-32 bg-muted" />
        </div>
        <Skeleton className="h-96 bg-muted" />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 space-y-6 max-w-6xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Calendar className="w-8 h-8" />
            Daily Routine Tracker
          </h1>
          <p className="text-muted-foreground mt-1">
            Record your daily activities for AI-powered health insights
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={handleDialogChange}>
          <DialogTrigger asChild>
            <Button size="lg">
              <Plus className="w-5 h-5 mr-2" />
              Add Activity
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Record Daily Activity</DialogTitle>
              <DialogDescription>
                Track your daily routine for better health monitoring
              </DialogDescription>
            </DialogHeader>
            {dialogOpen && (
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="activity_type"
                  rules={{ required: 'Activity type is required' }}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Activity Type</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select activity type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="exercise">🏃 Exercise</SelectItem>
                          <SelectItem value="meal">🍽️ Meal</SelectItem>
                          <SelectItem value="sleep">😴 Sleep</SelectItem>
                          <SelectItem value="medication">💊 Medication</SelectItem>
                          <SelectItem value="social">👥 Social</SelectItem>
                          <SelectItem value="cognitive">🧠 Cognitive Activity</SelectItem>
                          <SelectItem value="other">📋 Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="activity_name"
                  rules={{ required: 'Activity name is required' }}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Activity Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., Morning walk, Breakfast, etc." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="duration_minutes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Duration (minutes)</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="30" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="mood_rating"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Mood Rating (1-10)</FormLabel>
                      <FormControl>
                        <Input type="number" min="1" max="10" placeholder="8" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notes (Optional)</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Any additional notes..." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <DialogFooter>
                  <Button type="submit" disabled={submitting}>
                    {submitting ? 'Recording...' : 'Record Activity'}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
            )}
          </DialogContent>
        </Dialog>
      </div>

      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="card-shadow">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Total Activities
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stats.totalActivities}</div>
              <p className="text-xs text-muted-foreground mt-1">Last 7 days</p>
            </CardContent>
          </Card>

          <Card className="card-shadow">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Avg Duration
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold flex items-center gap-2">
                {stats.averageDuration}
                <span className="text-sm font-normal text-muted-foreground">min</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">Per activity</p>
            </CardContent>
          </Card>

          <Card className="card-shadow">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Avg Mood
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold flex items-center gap-2">
                {stats.averageMood || 'N/A'}
                {stats.averageMood && <span className="text-2xl">{getMoodEmoji(parseFloat(stats.averageMood))}</span>}
              </div>
              <p className="text-xs text-muted-foreground mt-1">Out of 10</p>
            </CardContent>
          </Card>

          <Card className="card-shadow">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Most Frequent
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold capitalize">
                {Object.entries(stats.activityCounts).sort((a, b) => (b[1] as number) - (a[1] as number))[0]?.[0].replace('_', ' ') || 'None'}
              </div>
              <p className="text-xs text-muted-foreground mt-1">Activity type</p>
            </CardContent>
          </Card>
        </div>
      )}

      <Card className="card-shadow">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5" />
            AI Analysis & Insights
          </CardTitle>
          <CardDescription>
            Based on your recent activity patterns
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
            <div className="flex items-start gap-3">
              <Brain className="w-5 h-5 text-primary mt-1" />
              <div>
                <p className="font-medium text-sm">Activity Pattern Analysis</p>
                <p className="text-sm text-muted-foreground mt-1">
                  {stats?.totalActivities > 0
                    ? `You've logged ${stats.totalActivities} activities in the past week. ${
                        stats.averageMood && parseFloat(stats.averageMood) >= 7
                          ? 'Your mood ratings indicate positive well-being. Keep up the great work!'
                          : stats.averageMood && parseFloat(stats.averageMood) >= 5
                          ? 'Your mood is stable. Consider adding more social or cognitive activities.'
                          : 'Consider increasing physical and social activities to improve mood.'
                      }`
                    : 'Start logging your daily activities to receive personalized insights.'}
                </p>
              </div>
            </div>
          </div>

          {stats?.activityCounts && Object.keys(stats.activityCounts).length > 0 && (
            <div className="p-4 rounded-lg bg-secondary/5 border border-secondary/20">
              <div className="flex items-start gap-3">
                <TrendingUp className="w-5 h-5 text-secondary mt-1" />
                <div>
                  <p className="font-medium text-sm">Routine Consistency</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    {stats.totalActivities >= 14
                      ? 'Excellent! You\'re maintaining a consistent daily routine.'
                      : stats.totalActivities >= 7
                      ? 'Good progress! Try to log activities more consistently.'
                      : 'Tip: Regular routine tracking helps AI detect patterns more accurately.'}
                  </p>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="card-shadow">
        <CardHeader>
          <CardTitle>Recent Activities</CardTitle>
          <CardDescription>Your logged daily routines</CardDescription>
        </CardHeader>
        <CardContent>
          {routines.length === 0 ? (
            <div className="text-center py-12">
              <Calendar className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Activities Yet</h3>
              <p className="text-muted-foreground mb-6">
                Start tracking your daily routine to get AI-powered insights
              </p>
              <Button onClick={() => setDialogOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add Your First Activity
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {routines.map((routine) => {
                const IconComponent = activityIcons[routine.activity_type];
                const isIcon = typeof IconComponent !== 'string';

                return (
                  <div
                    key={routine.id}
                    className={`p-4 rounded-lg border ${activityColors[routine.activity_type]} hover:shadow-md transition-shadow`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3 flex-1">
                        <div className="mt-1">
                          {isIcon ? (
                            <IconComponent className="w-5 h-5" />
                          ) : (
                            <span className="text-xl">{IconComponent}</span>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className="font-semibold">{routine.activity_name}</h4>
                            <Badge variant="outline" className="capitalize text-xs">
                              {routine.activity_type.replace('_', ' ')}
                            </Badge>
                          </div>
                          <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {routine.completed_at
                                ? format(new Date(routine.completed_at), 'MMM dd, yyyy HH:mm')
                                : 'Not completed'}
                            </span>
                            {routine.duration_minutes && (
                              <span>{routine.duration_minutes} min</span>
                            )}
                            {routine.mood_rating && (
                              <span className="flex items-center gap-1">
                                <Smile className="w-3 h-3" />
                                {routine.mood_rating}/10 {getMoodEmoji(routine.mood_rating)}
                              </span>
                            )}
                          </div>
                          {routine.notes && (
                            <p className="text-sm text-muted-foreground mt-2 line-clamp-2">
                              {routine.notes}
                            </p>
                          )}
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(routine.id)}
                        className="text-destructive hover:text-destructive hover:bg-destructive/10"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
