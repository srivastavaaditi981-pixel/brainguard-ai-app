import { useEffect, useState } from 'react';
import { useAuth } from 'miaoda-auth-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Switch } from '@/components/ui/switch';
import { Users, Plus, Trash2, Mail } from 'lucide-react';
import { getCaregiverAssignments, getProfile, removeCaregiverAssignment, addCaregiverAssignment, updateCaregiverPermissions, getAllProfiles } from '@/db/api';
import type { CaregiverAssignment, Profile } from '@/types/types';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';

export default function Caregivers() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [assignments, setAssignments] = useState<CaregiverAssignment[]>([]);
  const [caregiverProfiles, setCaregiverProfiles] = useState<Record<string, Profile>>({});
  const [dialogOpen, setDialogOpen] = useState(false);
  const [availableCaregivers, setAvailableCaregivers] = useState<Profile[]>([]);
  const [selectedCaregiver, setSelectedCaregiver] = useState('');
  const [relationship, setRelationship] = useState('');

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    try {
      setLoading(true);
      const assignmentsData = await getCaregiverAssignments(user!.id);
      setAssignments(assignmentsData);

      const profiles: Record<string, Profile> = {};
      for (const assignment of assignmentsData) {
        const profile = await getProfile(assignment.caregiver_id);
        if (profile) {
          profiles[assignment.caregiver_id] = profile;
        }
      }
      setCaregiverProfiles(profiles);

      const allProfiles = await getAllProfiles();
      const caregivers = allProfiles.filter(p => 
        (p.role === 'caregiver' || p.role === 'healthcare_professional') &&
        !assignmentsData.some(a => a.caregiver_id === p.id)
      );
      setAvailableCaregivers(caregivers);
    } catch (error: any) {
      toast({
        title: 'Error Loading Data',
        description: error.message || 'Failed to load caregivers',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleAddCaregiver = async () => {
    if (!selectedCaregiver) {
      toast({
        title: 'Select a Caregiver',
        description: 'Please select a caregiver to add',
        variant: 'destructive'
      });
      return;
    }

    try {
      await addCaregiverAssignment(user!.id, selectedCaregiver, relationship);
      toast({
        title: 'Caregiver Added',
        description: 'The caregiver has been added successfully'
      });
      setDialogOpen(false);
      setSelectedCaregiver('');
      setRelationship('');
      loadData();
    } catch (error: any) {
      toast({
        title: 'Error Adding Caregiver',
        description: error.message || 'Failed to add caregiver',
        variant: 'destructive'
      });
    }
  };

  const handleRemoveCaregiver = async (assignmentId: string) => {
    try {
      await removeCaregiverAssignment(assignmentId);
      toast({
        title: 'Caregiver Removed',
        description: 'The caregiver has been removed'
      });
      loadData();
    } catch (error: any) {
      toast({
        title: 'Error Removing Caregiver',
        description: error.message || 'Failed to remove caregiver',
        variant: 'destructive'
      });
    }
  };

  const handleTogglePermission = async (
    assignmentId: string,
    field: 'can_view_alerts' | 'can_view_data',
    currentValue: boolean
  ) => {
    try {
      const assignment = assignments.find(a => a.id === assignmentId);
      if (!assignment) return;

      await updateCaregiverPermissions(
        assignmentId,
        field === 'can_view_alerts' ? !currentValue : assignment.can_view_alerts,
        field === 'can_view_data' ? !currentValue : assignment.can_view_data
      );

      setAssignments(assignments.map(a =>
        a.id === assignmentId ? { ...a, [field]: !currentValue } : a
      ));

      toast({
        title: 'Permissions Updated',
        description: 'Caregiver permissions have been updated'
      });
    } catch (error: any) {
      toast({
        title: 'Error Updating Permissions',
        description: error.message || 'Failed to update permissions',
        variant: 'destructive'
      });
    }
  };

  const getInitials = (name?: string | null) => {
    if (!name) return 'U';
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  if (loading) {
    return (
      <div className="container mx-auto p-4 space-y-6">
        <Skeleton className="h-12 w-64 bg-muted" />
        <Skeleton className="h-96 w-full bg-muted" />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 space-y-6 max-w-4xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center gap-2">
            <Users className="w-8 h-8" />
            My Caregivers
          </h1>
          <p className="text-muted-foreground mt-1">Manage who can access your health data</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Add Caregiver
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Caregiver</DialogTitle>
              <DialogDescription>
                Grant access to a caregiver or healthcare professional
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="caregiver">Select Caregiver</Label>
                <Select value={selectedCaregiver} onValueChange={setSelectedCaregiver}>
                  <SelectTrigger id="caregiver">
                    <SelectValue placeholder="Choose a caregiver" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableCaregivers.map((caregiver) => (
                      <SelectItem key={caregiver.id} value={caregiver.id}>
                        {caregiver.full_name || caregiver.username} ({caregiver.role})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="relationship">Relationship (Optional)</Label>
                <Input
                  id="relationship"
                  value={relationship}
                  onChange={(e) => setRelationship(e.target.value)}
                  placeholder="e.g., Family, Doctor, Nurse"
                />
              </div>
              <Button onClick={handleAddCaregiver} className="w-full">
                Add Caregiver
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {assignments.length > 0 ? (
        <div className="space-y-4">
          {assignments.map((assignment) => {
            const caregiver = caregiverProfiles[assignment.caregiver_id];
            if (!caregiver) return null;

            return (
              <Card key={assignment.id} className="card-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-4">
                      <Avatar className="w-12 h-12">
                        <AvatarFallback className="bg-primary text-primary-foreground">
                          {getInitials(caregiver.full_name || caregiver.username)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <CardTitle>{caregiver.full_name || caregiver.username}</CardTitle>
                        <CardDescription className="flex items-center gap-2 mt-1">
                          <Mail className="w-3 h-3" />
                          {caregiver.email || caregiver.username}
                        </CardDescription>
                        <div className="flex gap-2 mt-2">
                          <Badge variant="secondary" className="capitalize">
                            {caregiver.role.replace('_', ' ')}
                          </Badge>
                          {assignment.relationship && (
                            <Badge variant="outline">{assignment.relationship}</Badge>
                          )}
                        </div>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleRemoveCaregiver(assignment.id)}
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label htmlFor={`alerts-${assignment.id}`}>Can View Alerts</Label>
                    <Switch
                      id={`alerts-${assignment.id}`}
                      checked={assignment.can_view_alerts}
                      onCheckedChange={() =>
                        handleTogglePermission(assignment.id, 'can_view_alerts', assignment.can_view_alerts)
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor={`data-${assignment.id}`}>Can View Monitoring Data</Label>
                    <Switch
                      id={`data-${assignment.id}`}
                      checked={assignment.can_view_data}
                      onCheckedChange={() =>
                        handleTogglePermission(assignment.id, 'can_view_data', assignment.can_view_data)
                      }
                    />
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Added on {new Date(assignment.created_at).toLocaleDateString()}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <Card className="card-shadow">
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <Users className="w-16 h-16 text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold mb-2">No Caregivers Yet</h3>
            <p className="text-muted-foreground mb-6">
              Add caregivers or healthcare professionals to help monitor your health
            </p>
            <Button onClick={() => setDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add Your First Caregiver
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
