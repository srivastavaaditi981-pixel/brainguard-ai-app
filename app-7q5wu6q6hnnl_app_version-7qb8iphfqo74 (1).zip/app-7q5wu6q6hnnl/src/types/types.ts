export type UserRole = 'senior' | 'caregiver' | 'healthcare_professional' | 'admin';

export interface Profile {
  id: string;
  username: string;
  email: string | null;
  phone: string | null;
  full_name: string | null;
  date_of_birth: string | null;
  role: UserRole;
  avatar_url: string | null;
  emergency_contact: string | null;
  medical_history: string | null;
  created_at: string;
  updated_at: string;
}

export type DataType = 'speech' | 'typing' | 'activity';

export interface MonitoringData {
  id: string;
  user_id: string;
  data_type: DataType;
  metrics: Record<string, any>;
  score: number | null;
  recorded_at: string;
}

export type AlertType = 'warning' | 'critical' | 'info';

export interface Alert {
  id: string;
  user_id: string;
  alert_type: AlertType;
  title: string;
  description: string | null;
  severity: number | null;
  is_read: boolean;
  created_at: string;
}

export type RecommendationCategory = 'cognitive_exercise' | 'lifestyle' | 'medical' | 'dietary' | 'physical';

export interface Recommendation {
  id: string;
  user_id: string;
  category: RecommendationCategory;
  title: string;
  description: string | null;
  is_completed: boolean;
  created_at: string;
}

export interface CaregiverAssignment {
  id: string;
  senior_id: string;
  caregiver_id: string;
  relationship: string | null;
  can_view_alerts: boolean;
  can_view_data: boolean;
  created_at: string;
}

export interface DashboardStats {
  cognitiveScore: number;
  alertCount: number;
  recommendationCount: number;
  lastMonitored: string | null;
}

export interface MonitoringMetrics {
  speechClarity?: number;
  speechPace?: number;
  typingSpeed?: number;
  typingAccuracy?: number;
  activityLevel?: number;
  sleepQuality?: number;
}

export type ActivityType = 'exercise' | 'medication' | 'meal' | 'sleep' | 'social' | 'cognitive' | 'other';

export interface DailyRoutine {
  id: string;
  user_id: string;
  activity_type: ActivityType;
  activity_name: string;
  scheduled_time: string | null;
  completed_at: string | null;
  duration_minutes: number | null;
  notes: string | null;
  mood_rating: number | null;
  ai_analysis: string | null;
  created_at: string;
}

export type AppointmentStatus = 'scheduled' | 'in_progress' | 'completed' | 'cancelled' | 'missed';

export interface VideoAppointment {
  id: string;
  senior_id: string;
  healthcare_id: string;
  scheduled_time: string;
  duration_minutes: number;
  status: AppointmentStatus;
  meeting_url: string | null;
  notes: string | null;
  reason: string | null;
  created_at: string;
  updated_at: string;
}
