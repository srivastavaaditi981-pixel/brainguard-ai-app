import type { ReactNode } from 'react';
import Home from './pages/Home';
import Monitoring from './pages/Monitoring';
import Alerts from './pages/Alerts';
import Recommendations from './pages/Recommendations';
import Profile from './pages/Profile';
import Caregivers from './pages/Caregivers';
import Patients from './pages/Patients';
import Admin from './pages/Admin';
import VideoCall from './pages/VideoCall';
import DailyRoutine from './pages/DailyRoutine';
import Login from './pages/Login';

export interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
  icon?: string;
}

const routes: RouteConfig[] = [
  {
    name: 'Dashboard',
    path: '/',
    element: <Home />,
    icon: 'LayoutDashboard'
  },
  {
    name: 'Daily Routine',
    path: '/daily-routine',
    element: <DailyRoutine />,
    icon: 'Calendar'
  },
  {
    name: 'Monitoring',
    path: '/monitoring',
    element: <Monitoring />,
    icon: 'Activity'
  },
  {
    name: 'Alerts',
    path: '/alerts',
    element: <Alerts />,
    icon: 'Bell'
  },
  {
    name: 'Video Call',
    path: '/video-call',
    element: <VideoCall />,
    icon: 'Video'
  },
  {
    name: 'Profile',
    path: '/profile',
    element: <Profile />,
    icon: 'User'
  },
  {
    name: 'Recommendations',
    path: '/recommendations',
    element: <Recommendations />,
    icon: 'Lightbulb'
  },
  {
    name: 'Caregivers',
    path: '/caregivers',
    element: <Caregivers />,
    icon: 'Users',
    visible: false
  },
  {
    name: 'Patients',
    path: '/patients',
    element: <Patients />,
    icon: 'Heart',
    visible: false
  },
  {
    name: 'Admin',
    path: '/admin',
    element: <Admin />,
    icon: 'Shield',
    visible: false
  },
  {
    name: 'Login',
    path: '/login',
    element: <Login />,
    visible: false
  }
];

export default routes;