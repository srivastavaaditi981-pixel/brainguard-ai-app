import { supabase } from './supabase';
import type {
  Profile,
  MonitoringData,
  Alert,
  Recommendation,
  CaregiverAssignment,
  UserRole,
  DataType,
  AlertType,
  RecommendationCategory,
  DailyRoutine,
  ActivityType,
  VideoAppointment,
  AppointmentStatus
} from '@/types/types';

// Profile APIs
export const getProfile = async (userId: string): Promise<Profile | null> => {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .maybeSingle();

  if (error) throw error;
  return data;
};

export const getCurrentProfile = async (): Promise<Profile | null> => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  return getProfile(user.id);
};

export const updateProfile = async (userId: string, updates: Partial<Profile>): Promise<Profile | null> => {
  const { data, error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', userId)
    .select()
    .maybeSingle();

  if (error) throw error;
  return data;
};

export const getAllProfiles = async (): Promise<Profile[]> => {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const updateUserRole = async (userId: string, role: UserRole): Promise<void> => {
  const { error } = await supabase
    .from('profiles')
    .update({ role })
    .eq('id', userId);

  if (error) throw error;
};

// Monitoring Data APIs
export const getMonitoringData = async (userId: string, limit = 50): Promise<MonitoringData[]> => {
  const { data, error } = await supabase
    .from('monitoring_data')
    .select('*')
    .eq('user_id', userId)
    .order('recorded_at', { ascending: false })
    .limit(limit);

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const getLatestMonitoringData = async (userId: string): Promise<MonitoringData | null> => {
  const { data, error } = await supabase
    .from('monitoring_data')
    .select('*')
    .eq('user_id', userId)
    .order('recorded_at', { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) throw error;
  return data;
};

export const addMonitoringData = async (
  userId: string,
  dataType: DataType,
  metrics: Record<string, any>,
  score?: number
): Promise<MonitoringData | null> => {
  const { data, error } = await supabase
    .from('monitoring_data')
    .insert({
      user_id: userId,
      data_type: dataType,
      metrics,
      score: score || null
    })
    .select()
    .maybeSingle();

  if (error) throw error;
  return data;
};

export const getMonitoringDataByType = async (
  userId: string,
  dataType: DataType,
  limit = 20
): Promise<MonitoringData[]> => {
  const { data, error } = await supabase
    .from('monitoring_data')
    .select('*')
    .eq('user_id', userId)
    .eq('data_type', dataType)
    .order('recorded_at', { ascending: false })
    .limit(limit);

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

// Alert APIs
export const getAlerts = async (userId: string): Promise<Alert[]> => {
  const { data, error } = await supabase
    .from('alerts')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const getUnreadAlerts = async (userId: string): Promise<Alert[]> => {
  const { data, error } = await supabase
    .from('alerts')
    .select('*')
    .eq('user_id', userId)
    .eq('is_read', false)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const markAlertAsRead = async (alertId: string): Promise<void> => {
  const { error } = await supabase
    .from('alerts')
    .update({ is_read: true })
    .eq('id', alertId);

  if (error) throw error;
};

export const createAlert = async (
  userId: string,
  alertType: AlertType,
  title: string,
  description?: string,
  severity?: number
): Promise<Alert | null> => {
  const { data, error } = await supabase
    .from('alerts')
    .insert({
      user_id: userId,
      alert_type: alertType,
      title,
      description: description || null,
      severity: severity || null
    })
    .select()
    .maybeSingle();

  if (error) throw error;
  return data;
};

// Recommendation APIs
export const getRecommendations = async (userId: string): Promise<Recommendation[]> => {
  const { data, error } = await supabase
    .from('recommendations')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const getActiveRecommendations = async (userId: string): Promise<Recommendation[]> => {
  const { data, error } = await supabase
    .from('recommendations')
    .select('*')
    .eq('user_id', userId)
    .eq('is_completed', false)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const toggleRecommendationComplete = async (
  recommendationId: string,
  isCompleted: boolean
): Promise<void> => {
  const { error } = await supabase
    .from('recommendations')
    .update({ is_completed: isCompleted })
    .eq('id', recommendationId);

  if (error) throw error;
};

export const createRecommendation = async (
  userId: string,
  category: RecommendationCategory,
  title: string,
  description?: string
): Promise<Recommendation | null> => {
  const { data, error } = await supabase
    .from('recommendations')
    .insert({
      user_id: userId,
      category,
      title,
      description: description || null
    })
    .select()
    .maybeSingle();

  if (error) throw error;
  return data;
};

// Caregiver Assignment APIs
export const getCaregiverAssignments = async (seniorId: string): Promise<CaregiverAssignment[]> => {
  const { data, error } = await supabase
    .from('caregiver_assignments')
    .select('*')
    .eq('senior_id', seniorId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const getAssignedSeniors = async (caregiverId: string): Promise<CaregiverAssignment[]> => {
  const { data, error } = await supabase
    .from('caregiver_assignments')
    .select('*')
    .eq('caregiver_id', caregiverId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const addCaregiverAssignment = async (
  seniorId: string,
  caregiverId: string,
  relationship?: string,
  canViewAlerts = true,
  canViewData = true
): Promise<CaregiverAssignment | null> => {
  const { data, error } = await supabase
    .from('caregiver_assignments')
    .insert({
      senior_id: seniorId,
      caregiver_id: caregiverId,
      relationship: relationship || null,
      can_view_alerts: canViewAlerts,
      can_view_data: canViewData
    })
    .select()
    .maybeSingle();

  if (error) throw error;
  return data;
};

export const removeCaregiverAssignment = async (assignmentId: string): Promise<void> => {
  const { error } = await supabase
    .from('caregiver_assignments')
    .delete()
    .eq('id', assignmentId);

  if (error) throw error;
};

export const updateCaregiverPermissions = async (
  assignmentId: string,
  canViewAlerts: boolean,
  canViewData: boolean
): Promise<void> => {
  const { error } = await supabase
    .from('caregiver_assignments')
    .update({
      can_view_alerts: canViewAlerts,
      can_view_data: canViewData
    })
    .eq('id', assignmentId);

  if (error) throw error;
};

// Dashboard Stats
export const getDashboardStats = async (userId: string) => {
  const [latestData, unreadAlerts, activeRecommendations] = await Promise.all([
    getLatestMonitoringData(userId),
    getUnreadAlerts(userId),
    getActiveRecommendations(userId)
  ]);

  return {
    cognitiveScore: latestData?.score || 0,
    alertCount: unreadAlerts.length,
    recommendationCount: activeRecommendations.length,
    lastMonitored: latestData?.recorded_at || null
  };
};

// Daily Routine APIs
export const getDailyRoutines = async (userId: string, limit?: number): Promise<DailyRoutine[]> => {
  let query = supabase
    .from('daily_routines')
    .select('*')
    .eq('user_id', userId)
    .order('completed_at', { ascending: false });

  if (limit) {
    query = query.limit(limit);
  }

  const { data, error } = await query;

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const getDailyRoutinesByDateRange = async (
  userId: string,
  startDate: string,
  endDate: string
): Promise<DailyRoutine[]> => {
  const { data, error } = await supabase
    .from('daily_routines')
    .select('*')
    .eq('user_id', userId)
    .gte('completed_at', startDate)
    .lte('completed_at', endDate)
    .order('completed_at', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const getTodayRoutines = async (userId: string): Promise<DailyRoutine[]> => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);

  const { data, error } = await supabase
    .from('daily_routines')
    .select('*')
    .eq('user_id', userId)
    .gte('completed_at', today.toISOString())
    .lt('completed_at', tomorrow.toISOString())
    .order('completed_at', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createDailyRoutine = async (routine: {
  user_id: string;
  activity_type: ActivityType;
  activity_name: string;
  scheduled_time?: string;
  completed_at?: string;
  duration_minutes?: number;
  notes?: string;
  mood_rating?: number;
}): Promise<DailyRoutine | null> => {
  const { data, error } = await supabase
    .from('daily_routines')
    .insert({
      user_id: routine.user_id,
      activity_type: routine.activity_type,
      activity_name: routine.activity_name,
      scheduled_time: routine.scheduled_time || null,
      completed_at: routine.completed_at || new Date().toISOString(),
      duration_minutes: routine.duration_minutes || null,
      notes: routine.notes || null,
      mood_rating: routine.mood_rating || null
    })
    .select()
    .maybeSingle();

  if (error) throw error;
  return data;
};

export const updateDailyRoutine = async (
  routineId: string,
  updates: Partial<DailyRoutine>
): Promise<DailyRoutine | null> => {
  const { data, error } = await supabase
    .from('daily_routines')
    .update(updates)
    .eq('id', routineId)
    .select()
    .maybeSingle();

  if (error) throw error;
  return data;
};

export const deleteDailyRoutine = async (routineId: string): Promise<void> => {
  const { error } = await supabase
    .from('daily_routines')
    .delete()
    .eq('id', routineId);

  if (error) throw error;
};

export const getRoutineStats = async (userId: string, days: number = 7) => {
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - days);

  const routines = await getDailyRoutinesByDateRange(
    userId,
    startDate.toISOString(),
    new Date().toISOString()
  );

  const activityCounts: Record<string, number> = {};
  let totalDuration = 0;
  let moodSum = 0;
  let moodCount = 0;

  routines.forEach(routine => {
    activityCounts[routine.activity_type] = (activityCounts[routine.activity_type] || 0) + 1;
    if (routine.duration_minutes) {
      totalDuration += routine.duration_minutes;
    }
    if (routine.mood_rating) {
      moodSum += routine.mood_rating;
      moodCount++;
    }
  });

  return {
    totalActivities: routines.length,
    activityCounts,
    averageDuration: routines.length > 0 ? Math.round(totalDuration / routines.length) : 0,
    averageMood: moodCount > 0 ? (moodSum / moodCount).toFixed(1) : null,
    routines
  };
};
