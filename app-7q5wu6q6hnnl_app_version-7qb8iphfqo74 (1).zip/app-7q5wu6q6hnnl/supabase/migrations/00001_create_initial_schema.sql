/*
# Create Initial Schema for Brain Guard

## 1. New Tables

### profiles
- `id` (uuid, primary key, references auth.users)
- `username` (text, unique, not null)
- `email` (text, unique)
- `phone` (text)
- `full_name` (text)
- `date_of_birth` (date)
- `role` (user_role enum: senior, caregiver, healthcare_professional, admin)
- `avatar_url` (text)
- `emergency_contact` (text)
- `medical_history` (text)
- `created_at` (timestamptz, default: now())
- `updated_at` (timestamptz, default: now())

### monitoring_data
- `id` (uuid, primary key)
- `user_id` (uuid, references profiles)
- `data_type` (text: speech, typing, activity)
- `metrics` (jsonb: stores various metrics)
- `score` (numeric: cognitive health score 0-100)
- `recorded_at` (timestamptz, default: now())

### alerts
- `id` (uuid, primary key)
- `user_id` (uuid, references profiles - the senior)
- `alert_type` (text: warning, critical, info)
- `title` (text, not null)
- `description` (text)
- `severity` (integer: 1-5)
- `is_read` (boolean, default: false)
- `created_at` (timestamptz, default: now())

### recommendations
- `id` (uuid, primary key)
- `user_id` (uuid, references profiles)
- `category` (text: cognitive_exercise, lifestyle, medical, dietary, physical)
- `title` (text, not null)
- `description` (text)
- `is_completed` (boolean, default: false)
- `created_at` (timestamptz, default: now())

### caregiver_assignments
- `id` (uuid, primary key)
- `senior_id` (uuid, references profiles)
- `caregiver_id` (uuid, references profiles)
- `relationship` (text: family, professional, friend)
- `can_view_alerts` (boolean, default: true)
- `can_view_data` (boolean, default: true)
- `created_at` (timestamptz, default: now())

## 2. Security

- Enable RLS on all tables
- Create helper functions for role checking
- Policies:
  - Admins have full access to all data
  - Seniors can view/edit their own data
  - Caregivers can view data of assigned seniors
  - Healthcare professionals can view data of assigned seniors
  - Users can view their own profile and update non-role fields

## 3. Triggers

- Auto-update `updated_at` timestamp on profiles
- Create first user as admin
- Sync auth.users to profiles table

## 4. Notes

- JSONB used for flexible monitoring metrics storage
- Role-based access control implemented
- First registered user becomes admin
*/

-- Create user role enum
CREATE TYPE user_role AS ENUM ('senior', 'caregiver', 'healthcare_professional', 'admin');

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE NOT NULL,
  email text UNIQUE,
  phone text,
  full_name text,
  date_of_birth date,
  role user_role DEFAULT 'senior'::user_role NOT NULL,
  avatar_url text,
  emergency_contact text,
  medical_history text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create monitoring_data table
CREATE TABLE IF NOT EXISTS monitoring_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  data_type text NOT NULL CHECK (data_type IN ('speech', 'typing', 'activity')),
  metrics jsonb NOT NULL DEFAULT '{}'::jsonb,
  score numeric CHECK (score >= 0 AND score <= 100),
  recorded_at timestamptz DEFAULT now()
);

-- Create alerts table
CREATE TABLE IF NOT EXISTS alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  alert_type text NOT NULL CHECK (alert_type IN ('warning', 'critical', 'info')),
  title text NOT NULL,
  description text,
  severity integer CHECK (severity >= 1 AND severity <= 5),
  is_read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create recommendations table
CREATE TABLE IF NOT EXISTS recommendations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  category text NOT NULL CHECK (category IN ('cognitive_exercise', 'lifestyle', 'medical', 'dietary', 'physical')),
  title text NOT NULL,
  description text,
  is_completed boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create caregiver_assignments table
CREATE TABLE IF NOT EXISTS caregiver_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  senior_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  caregiver_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  relationship text,
  can_view_alerts boolean DEFAULT true,
  can_view_data boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  UNIQUE(senior_id, caregiver_id)
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE monitoring_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE recommendations ENABLE ROW LEVEL SECURITY;
ALTER TABLE caregiver_assignments ENABLE ROW LEVEL SECURITY;

-- Helper function to check if user is admin
CREATE OR REPLACE FUNCTION is_admin(uid uuid)
RETURNS boolean LANGUAGE sql SECURITY DEFINER AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = uid AND p.role = 'admin'::user_role
  );
$$;

-- Helper function to check if user is caregiver for a senior
CREATE OR REPLACE FUNCTION is_caregiver_for(caregiver_uid uuid, senior_uid uuid)
RETURNS boolean LANGUAGE sql SECURITY DEFINER AS $$
  SELECT EXISTS (
    SELECT 1 FROM caregiver_assignments ca
    WHERE ca.caregiver_id = caregiver_uid AND ca.senior_id = senior_uid
  );
$$;

-- Profiles policies
CREATE POLICY "Admins have full access to profiles" ON profiles
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can view own profile" ON profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile without changing role" ON profiles
  FOR UPDATE USING (auth.uid() = id) 
  WITH CHECK (role IS NOT DISTINCT FROM (SELECT role FROM profiles WHERE id = auth.uid()));

CREATE POLICY "Caregivers can view assigned seniors profiles" ON profiles
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM caregiver_assignments ca
      WHERE ca.senior_id = profiles.id AND ca.caregiver_id = auth.uid()
    )
  );

-- Monitoring data policies
CREATE POLICY "Admins have full access to monitoring_data" ON monitoring_data
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can view own monitoring data" ON monitoring_data
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own monitoring data" ON monitoring_data
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Caregivers can view assigned seniors monitoring data" ON monitoring_data
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM caregiver_assignments ca
      WHERE ca.senior_id = monitoring_data.user_id 
        AND ca.caregiver_id = auth.uid()
        AND ca.can_view_data = true
    )
  );

-- Alerts policies
CREATE POLICY "Admins have full access to alerts" ON alerts
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can view own alerts" ON alerts
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can update own alerts" ON alerts
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "System can insert alerts" ON alerts
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Caregivers can view assigned seniors alerts" ON alerts
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM caregiver_assignments ca
      WHERE ca.senior_id = alerts.user_id 
        AND ca.caregiver_id = auth.uid()
        AND ca.can_view_alerts = true
    )
  );

-- Recommendations policies
CREATE POLICY "Admins have full access to recommendations" ON recommendations
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can view own recommendations" ON recommendations
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can update own recommendations" ON recommendations
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "System can insert recommendations" ON recommendations
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Caregivers can view assigned seniors recommendations" ON recommendations
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM caregiver_assignments ca
      WHERE ca.senior_id = recommendations.user_id AND ca.caregiver_id = auth.uid()
    )
  );

-- Caregiver assignments policies
CREATE POLICY "Admins have full access to caregiver_assignments" ON caregiver_assignments
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Seniors can view own caregiver assignments" ON caregiver_assignments
  FOR SELECT USING (auth.uid() = senior_id);

CREATE POLICY "Seniors can manage own caregiver assignments" ON caregiver_assignments
  FOR ALL USING (auth.uid() = senior_id);

CREATE POLICY "Caregivers can view their assignments" ON caregiver_assignments
  FOR SELECT USING (auth.uid() = caregiver_id);

-- Trigger function to handle new user registration
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count int;
  extracted_username text;
BEGIN
  -- Only insert into profiles after user is confirmed
  IF OLD IS DISTINCT FROM NULL AND OLD.confirmed_at IS NULL AND NEW.confirmed_at IS NOT NULL THEN
    -- Count existing users in profiles
    SELECT COUNT(*) INTO user_count FROM profiles;
    
    -- Extract username from email (remove @miaoda.com)
    extracted_username := REPLACE(NEW.email, '@miaoda.com', '');
    
    -- Insert into profiles, first user gets admin role
    INSERT INTO profiles (id, username, email, phone, role)
    VALUES (
      NEW.id,
      extracted_username,
      CASE WHEN NEW.email LIKE '%@miaoda.com' THEN NULL ELSE NEW.email END,
      NEW.phone,
      CASE WHEN user_count = 0 THEN 'admin'::user_role ELSE 'senior'::user_role END
    );
  END IF;
  RETURN NEW;
END;
$$;

-- Create trigger for new user registration
DROP TRIGGER IF EXISTS on_auth_user_confirmed ON auth.users;
CREATE TRIGGER on_auth_user_confirmed
  AFTER UPDATE ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();

-- Trigger function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for profiles updated_at
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create indexes for better performance
CREATE INDEX idx_monitoring_data_user_id ON monitoring_data(user_id);
CREATE INDEX idx_monitoring_data_recorded_at ON monitoring_data(recorded_at DESC);
CREATE INDEX idx_alerts_user_id ON alerts(user_id);
CREATE INDEX idx_alerts_created_at ON alerts(created_at DESC);
CREATE INDEX idx_recommendations_user_id ON recommendations(user_id);
CREATE INDEX idx_caregiver_assignments_senior_id ON caregiver_assignments(senior_id);
CREATE INDEX idx_caregiver_assignments_caregiver_id ON caregiver_assignments(caregiver_id);