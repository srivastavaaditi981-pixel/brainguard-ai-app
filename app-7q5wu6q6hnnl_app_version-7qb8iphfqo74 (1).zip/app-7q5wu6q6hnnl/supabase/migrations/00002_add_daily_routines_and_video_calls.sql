/*
# Add Daily Routines and Video Appointments Tables

## 1. New Tables

### daily_routines
- `id` (uuid, primary key)
- `user_id` (uuid, references profiles)
- `activity_type` (text) - e.g., 'exercise', 'medication', 'meal', 'sleep', 'social', 'cognitive'
- `activity_name` (text) - name/description of the activity
- `scheduled_time` (time) - when the activity is scheduled
- `completed_at` (timestamptz) - when it was actually completed
- `duration_minutes` (integer) - how long it took
- `notes` (text) - additional notes
- `mood_rating` (integer) - 1-5 rating of mood during activity
- `ai_analysis` (text) - AI-generated insights
- `created_at` (timestamptz)

### video_appointments
- `id` (uuid, primary key)
- `senior_id` (uuid, references profiles) - the senior user
- `healthcare_id` (uuid, references profiles) - the healthcare professional
- `scheduled_time` (timestamptz) - appointment date/time
- `duration_minutes` (integer) - expected duration
- `status` (text) - 'scheduled', 'completed', 'cancelled', 'missed'
- `meeting_url` (text) - video call link
- `notes` (text) - appointment notes
- `reason` (text) - reason for appointment
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

## 2. Security
- Enable RLS on both tables
- Seniors can view/edit their own routines and appointments
- Healthcare professionals can view appointments with their assigned seniors
- Admins have full access
*/

-- Create activity type enum
CREATE TYPE activity_type AS ENUM ('exercise', 'medication', 'meal', 'sleep', 'social', 'cognitive', 'other');

-- Create appointment status enum
CREATE TYPE appointment_status AS ENUM ('scheduled', 'in_progress', 'completed', 'cancelled', 'missed');

-- Create daily_routines table
CREATE TABLE IF NOT EXISTS daily_routines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  activity_type activity_type NOT NULL,
  activity_name text NOT NULL,
  scheduled_time time,
  completed_at timestamptz,
  duration_minutes integer,
  notes text,
  mood_rating integer CHECK (mood_rating >= 1 AND mood_rating <= 5),
  ai_analysis text,
  created_at timestamptz DEFAULT now()
);

-- Create video_appointments table
CREATE TABLE IF NOT EXISTS video_appointments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  senior_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  healthcare_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  scheduled_time timestamptz NOT NULL,
  duration_minutes integer DEFAULT 30,
  status appointment_status DEFAULT 'scheduled'::appointment_status NOT NULL,
  meeting_url text,
  notes text,
  reason text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX idx_daily_routines_user_id ON daily_routines(user_id);
CREATE INDEX idx_daily_routines_completed_at ON daily_routines(completed_at);
CREATE INDEX idx_video_appointments_senior_id ON video_appointments(senior_id);
CREATE INDEX idx_video_appointments_healthcare_id ON video_appointments(healthcare_id);
CREATE INDEX idx_video_appointments_scheduled_time ON video_appointments(scheduled_time);

-- Enable RLS
ALTER TABLE daily_routines ENABLE ROW LEVEL SECURITY;
ALTER TABLE video_appointments ENABLE ROW LEVEL SECURITY;

-- Policies for daily_routines
CREATE POLICY "Users can view own routines" ON daily_routines
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own routines" ON daily_routines
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own routines" ON daily_routines
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own routines" ON daily_routines
  FOR DELETE USING (auth.uid() = user_id);

CREATE POLICY "Admins have full access to routines" ON daily_routines
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Caregivers can view assigned seniors routines" ON daily_routines
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM caregiver_assignments ca
      WHERE ca.senior_id = daily_routines.user_id
      AND ca.caregiver_id = auth.uid()
      AND ca.can_view_data = true
    )
  );

-- Policies for video_appointments
CREATE POLICY "Seniors can view own appointments" ON video_appointments
  FOR SELECT USING (auth.uid() = senior_id);

CREATE POLICY "Healthcare can view their appointments" ON video_appointments
  FOR SELECT USING (auth.uid() = healthcare_id);

CREATE POLICY "Seniors can create appointments" ON video_appointments
  FOR INSERT WITH CHECK (auth.uid() = senior_id);

CREATE POLICY "Healthcare can create appointments" ON video_appointments
  FOR INSERT WITH CHECK (auth.uid() = healthcare_id);

CREATE POLICY "Participants can update appointments" ON video_appointments
  FOR UPDATE USING (auth.uid() = senior_id OR auth.uid() = healthcare_id);

CREATE POLICY "Participants can delete appointments" ON video_appointments
  FOR DELETE USING (auth.uid() = senior_id OR auth.uid() = healthcare_id);

CREATE POLICY "Admins have full access to appointments" ON video_appointments
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

-- Trigger for updated_at
CREATE TRIGGER update_video_appointments_updated_at
  BEFORE UPDATE ON video_appointments
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();