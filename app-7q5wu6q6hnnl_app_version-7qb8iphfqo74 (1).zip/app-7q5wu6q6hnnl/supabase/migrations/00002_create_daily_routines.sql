/*
# Create Daily Routines Table for AI Analysis

## 1. New Tables

### daily_routines
- `id` (uuid, primary key, default: gen_random_uuid())
- `user_id` (uuid, references profiles(id), not null)
- `activity_type` (activity_type enum: exercise, meal, sleep, medication, social, cognitive, other)
- `title` (text, not null)
- `description` (text)
- `activity_time` (timestamptz, not null)
- `duration_minutes` (integer)
- `mood` (text) - user's mood during/after activity
- `notes` (text)
- `created_at` (timestamptz, default: now())

## 2. Security
- Enable RLS on `daily_routines` table
- Users can view their own routines
- Users can create their own routines
- Users can update their own routines
- Users can delete their own routines
- Caregivers and healthcare professionals can view routines of their assigned patients
- Admins have full access

## 3. Indexes
- Index on user_id for faster queries
- Index on activity_time for time-based queries

## 4. Notes
- This table stores daily activities and routines for AI analysis
- AI can analyze patterns, consistency, and anomalies
- Helps in early detection of cognitive decline through routine changes
*/

-- Create activity type enum
CREATE TYPE activity_type AS ENUM (
  'exercise',
  'meal',
  'sleep',
  'medication',
  'social',
  'cognitive',
  'other'
);

-- Create daily_routines table
CREATE TABLE IF NOT EXISTS daily_routines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  activity_type activity_type NOT NULL,
  title text NOT NULL,
  description text,
  activity_time timestamptz NOT NULL,
  duration_minutes integer,
  mood text,
  notes text,
  created_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX idx_daily_routines_user_id ON daily_routines(user_id);
CREATE INDEX idx_daily_routines_activity_time ON daily_routines(activity_time DESC);
CREATE INDEX idx_daily_routines_user_time ON daily_routines(user_id, activity_time DESC);

-- Enable RLS
ALTER TABLE daily_routines ENABLE ROW LEVEL SECURITY;

-- Policy: Users can view their own routines
CREATE POLICY "Users can view own routines" ON daily_routines
  FOR SELECT USING (auth.uid() = user_id);

-- Policy: Users can create their own routines
CREATE POLICY "Users can create own routines" ON daily_routines
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Policy: Users can update their own routines
CREATE POLICY "Users can update own routines" ON daily_routines
  FOR UPDATE USING (auth.uid() = user_id);

-- Policy: Users can delete their own routines
CREATE POLICY "Users can delete own routines" ON daily_routines
  FOR DELETE USING (auth.uid() = user_id);

-- Policy: Caregivers can view routines of their assigned patients
CREATE POLICY "Caregivers can view patient routines" ON daily_routines
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM caregiver_assignments ca
      WHERE ca.caregiver_id = auth.uid()
      AND ca.senior_id = daily_routines.user_id
    )
  );

-- Policy: Admins have full access
CREATE POLICY "Admins have full access to routines" ON daily_routines
  FOR ALL USING (is_admin(auth.uid()));
